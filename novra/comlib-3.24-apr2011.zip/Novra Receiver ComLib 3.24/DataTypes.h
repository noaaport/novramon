#ifndef _DATATYPE

#define DATATYPE


enum DataType {

	NO_TYPE,
	_STRING,
	_SHORT,
	_LONG,
	_I64,
	_FLOAT,
	_FLAG

};


#endif

