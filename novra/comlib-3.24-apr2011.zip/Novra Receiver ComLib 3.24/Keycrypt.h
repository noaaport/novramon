void encryptCSAkeys(unsigned short * ptrKeyTable, int numKeys );

